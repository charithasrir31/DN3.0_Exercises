package com.example.EmployeeManagementSystem.controller;

import com.example.EmployeeManagementSystem.model.Employee;
import com.example.EmployeeManagementSystem.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping
    public Page<Employee> getEmployees(@PageableDefault(size = 10) Pageable pageable) {
        return employeeService.getEmployeesWithPagination(pageable);
    }

    @GetMapping("/search")
    public Page<Employee> searchEmployeesByName(@RequestParam String name, @PageableDefault(size = 10) Pageable pageable) {
        return employeeService.getEmployeesByNameWithPagination(name, pageable);
    }
}
